// Rotas do catálogo técnico para a API Node.js (a mesma que atende a Área do Cliente).
// Montar com:  app.use('/catalogo', require('./catalogo')(pool, auth));
//   pool = conexão mssql com o login api_site · auth = middleware que põe req.usuario (Área do Cliente)
// Regras: peso ao vivo do ERP; equivalências só na busca (nunca na resposta); inativo = "sob_consulta".

const express = require('express');
const sql = require('mssql');

const norm = (s) => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
const CAMPOS = `codigo, descricao, aplicacao, linha, funcao, tabelado, medida_a_mm, medida_b_mm, medida_c_mm, medida_e_mm,
                desenho_arquivo, desenho_hash, situacao, peso_kg_m, cores_pronta_entrega, novo_ate`;

function limpa(r) {   // formato público: nada de fabricante nem de equivalência
  return {
    codigo: r.codigo, descricao: r.descricao, aplicacao: r.aplicacao, linha: r.linha, funcao: r.funcao,
    tabelado: !!r.tabelado, medidas: r.tabelado ? { a: r.medida_a_mm, b: r.medida_b_mm, c: r.medida_c_mm, e: r.medida_e_mm } : undefined,
    desenho: r.desenho_arquivo ? `/desenhos/${r.codigo}.svg?v=${(r.desenho_hash || '').slice(0, 8)}` : null,
    situacao: r.situacao, peso_kg_m: r.peso_kg_m,
    cores_pronta_entrega: r.cores_pronta_entrega ? r.cores_pronta_entrega.split(',') : [],
    novo: r.novo_ate ? new Date(r.novo_ate) >= new Date() : false,
  };
}

module.exports = (pool, auth) => {
  const r = express.Router();

  // Versão do catálogo (o site usa para decidir se republica)
  r.get('/versao', async (_req, res) => {
    const q = await pool.request().query('SELECT versao, perfis FROM site.vw_catalogo_versao');
    res.set('Cache-Control', 'no-store').json(q.recordset[0]);
  });

  // Catálogo completo (o site gera as páginas a partir daqui) — ~930 perfis, cabe numa resposta
  r.get('/perfis', async (_req, res) => {
    const q = await pool.request().query(`SELECT ${CAMPOS} FROM site.vw_catalogo ORDER BY codigo`);
    res.set('Cache-Control', 'public, max-age=300').json(q.recordset.map(limpa));
  });

  // Busca: código Alplan, qualquer código equivalente (não exibido) ou descrição
  r.get('/busca', async (req, res) => {
    const termo = String(req.query.q || '').trim().slice(0, 60);
    if (termo.length < 2) return res.json([]);
    const q = await pool.request()
      .input('n', sql.VarChar(60), norm(termo) + '%')
      .input('t', sql.NVarChar(62), '%' + termo + '%')
      .query(`SELECT TOP 50 ${CAMPOS} FROM site.vw_catalogo c
              WHERE REPLACE(c.codigo,'-','') LIKE @n
                 OR c.descricao LIKE @t
                 OR EXISTS (SELECT 1 FROM site.catalogo_equivalencia e WHERE e.codigo = c.codigo AND e.codigo_busca LIKE @n)
              ORDER BY CASE WHEN REPLACE(c.codigo,'-','') LIKE @n THEN 0 ELSE 1 END, c.codigo`);
    res.json(q.recordset.map(limpa));
  });

  r.get('/perfis/:codigo', async (req, res) => {
    const q = await pool.request().input('c', sql.VarChar(20), req.params.codigo)
      .query(`SELECT ${CAMPOS} FROM site.vw_catalogo WHERE codigo = @c`);
    if (!q.recordset.length) return res.status(404).json({ erro: 'Perfil não encontrado' });
    res.json(limpa(q.recordset[0]));
  });

  // Pedido de orçamento (visitante ou cliente logado). Destino final (e-mail / WhatsApp / ERP): PENDENTE.
  r.post('/orcamentos', express.json({ limit: '50kb' }), async (req, res) => {
    const b = req.body || {}; const itens = Array.isArray(b.itens) ? b.itens.slice(0, 200) : [];
    if (!itens.length) return res.status(400).json({ erro: 'Orçamento sem itens' });
    if (!req.usuario && (!b.nome || !(b.email || b.telefone) || !b.aceite_lgpd))
      return res.status(400).json({ erro: 'Informe nome, e-mail ou telefone e aceite a política de privacidade' });
    for (const i of itens) {
      if (!/^[A-Z0-9-]{2,20}$/.test(i.codigo || '') || !/^[A-Z0-9]{2,10}$/.test(i.cor || '') || !(Number.isInteger(i.barras) && i.barras > 0 && i.barras <= 10000))
        return res.status(400).json({ erro: 'Item inválido', item: i });
    }
    const tx = new sql.Transaction(pool); await tx.begin();
    try {
      const o = await new sql.Request(tx)
        .input('u', sql.Int, req.usuario ? req.usuario.id : null)
        .input('nome', sql.NVarChar(120), b.nome || null).input('emp', sql.NVarChar(120), b.empresa || null)
        .input('doc', sql.VarChar(18), b.documento || null).input('mail', sql.VarChar(160), b.email || null)
        .input('tel', sql.VarChar(30), b.telefone || null).input('cid', sql.NVarChar(80), b.cidade || null)
        .input('obs', sql.NVarChar(1000), (b.observacao || '').slice(0, 1000)).input('lgpd', sql.Bit, b.aceite_lgpd ? 1 : 0)
        .query(`INSERT INTO site.orcamento (usuario_id,nome,empresa,documento,email,telefone,cidade,observacao,aceite_lgpd)
                OUTPUT inserted.id, inserted.numero VALUES (@u,@nome,@emp,@doc,@mail,@tel,@cid,@obs,@lgpd)`);
      const { id, numero } = o.recordset[0];
      for (const i of itens) {
        await new sql.Request(tx).input('o', sql.Int, id).input('c', sql.VarChar(20), i.codigo)
          .input('cor', sql.VarChar(10), i.cor).input('b', sql.Int, i.barras)
          .query(`INSERT INTO site.orcamento_item (orcamento_id,codigo,cor_codigo,barras,pronta_entrega_na_hora,peso_kg_m_na_hora)
                  SELECT @o, @c, @cor, @b,
                         CASE WHEN EXISTS (SELECT 1 FROM site.vw_catalogo_produto_cor e WHERE e.codigo=@c AND e.cor_codigo=@cor AND e.pronta_entrega=1) THEN 1 ELSE 0 END,
                         (SELECT peso_kg_m FROM site.vw_catalogo WHERE codigo=@c)`);
      }
      await tx.commit();
      // TODO destino: avisar o comercial (e-mail/WhatsApp) ou gravar no ERP — a definir com o cliente.
      res.status(201).json({ numero });
    } catch (e) { await tx.rollback(); throw e; }
  });

  // Área do Cliente: catálogos salvos e orçamentos do próprio cliente
  r.get('/meus/catalogos', auth, async (req, res) => {
    const q = await pool.request().input('u', sql.Int, req.usuario.id).query(
      `SELECT s.id, s.nome, s.criado_em, STRING_AGG(i.codigo, ',') WITHIN GROUP (ORDER BY i.ordem) AS codigos
       FROM site.catalogo_salvo s LEFT JOIN site.catalogo_salvo_item i ON i.catalogo_id = s.id
       WHERE s.usuario_id = @u GROUP BY s.id, s.nome, s.criado_em ORDER BY s.criado_em DESC`);
    res.json(q.recordset.map((x) => ({ ...x, codigos: x.codigos ? x.codigos.split(',') : [] })));
  });
  r.post('/meus/catalogos', auth, express.json(), async (req, res) => {
    const nome = String(req.body.nome || 'Meu catálogo').slice(0, 80);
    const cods = (req.body.codigos || []).filter((c) => /^[A-Z0-9-]{2,20}$/.test(c)).slice(0, 500);
    const tx = new sql.Transaction(pool); await tx.begin();
    try {
      const s = await new sql.Request(tx).input('u', sql.Int, req.usuario.id).input('n', sql.NVarChar(80), nome)
        .query('INSERT INTO site.catalogo_salvo (usuario_id,nome) OUTPUT inserted.id VALUES (@u,@n)');
      const id = s.recordset[0].id;
      for (const [k, c] of cods.entries())
        await new sql.Request(tx).input('i', sql.Int, id).input('c', sql.VarChar(20), c).input('o', sql.Int, k)
          .query('INSERT INTO site.catalogo_salvo_item (catalogo_id,codigo,ordem) VALUES (@i,@c,@o)');
      await tx.commit(); res.status(201).json({ id });
    } catch (e) { await tx.rollback(); throw e; }
  });
  r.delete('/meus/catalogos/:id', auth, async (req, res) => {
    await pool.request().input('i', sql.Int, +req.params.id).input('u', sql.Int, req.usuario.id)
      .query('DELETE FROM site.catalogo_salvo WHERE id=@i AND usuario_id=@u');
    res.status(204).end();
  });
  r.get('/meus/orcamentos', auth, async (req, res) => {
    const q = await pool.request().input('u', sql.Int, req.usuario.id).query(
      `SELECT o.numero, o.status, o.criado_em, COUNT(i.codigo) AS itens, SUM(i.barras) AS barras
       FROM site.orcamento o JOIN site.orcamento_item i ON i.orcamento_id = o.id
       WHERE o.usuario_id = @u GROUP BY o.numero, o.status, o.criado_em ORDER BY o.criado_em DESC`);
    res.json(q.recordset);
  });

  return r;
};
