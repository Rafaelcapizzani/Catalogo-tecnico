// Publicação automática do catálogo: roda junto da API, no servidor da empresa.
// A cada 5 minutos lê site.vw_catalogo_versao (muda quando peso, situação, cor ou cadastro muda no ERP)
// e, se mudou, avisa o site (Vercel) para refazer as páginas do catálogo. Sem porta aberta: a chamada sai do servidor.
//
// Variáveis: SITE_URL=https://www.<dominio>  ·  SITE_REVALIDATE_SECRET=<segredo compartilhado com o site>
// Uso no index da API:  require('./publicador')(pool);
const fs = require('fs');
const path = require('path');
const ARQ = path.join(__dirname, '.catalogo-versao');   // guarda a última versão publicada (sobrevive a reinício)

module.exports = (pool, { intervaloMin = 5 } = {}) => {
  let ultima = null;
  try { ultima = fs.readFileSync(ARQ, 'utf8').trim(); } catch (_) {}

  async function verifica() {
    try {
      const q = await pool.request().query('SELECT versao, perfis FROM site.vw_catalogo_versao');
      const atual = String(q.recordset[0].versao);
      if (atual === ultima) return;
      const r = await fetch(`${process.env.SITE_URL}/api/catalogo/revalidar`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', authorization: `Bearer ${process.env.SITE_REVALIDATE_SECRET}` },
        body: JSON.stringify({ versao: atual, perfis: q.recordset[0].perfis }),
      });
      if (!r.ok) throw new Error(`site respondeu ${r.status}`);
      ultima = atual; fs.writeFileSync(ARQ, atual);
      console.log(new Date().toISOString(), 'catálogo republicado, versão', atual);
    } catch (e) {
      console.error(new Date().toISOString(), 'publicação do catálogo falhou (tenta de novo no próximo ciclo):', e.message);
    }
  }
  verifica();
  return setInterval(verifica, intervaloMin * 60 * 1000);
};

// Desenhos: servidos pela própria API, com cache longo (o ?v= muda quando o SVG muda).
// app.get('/desenhos/:arquivo', (req, res) => {
//   const nome = path.basename(req.params.arquivo);                    // impede ../
//   if (!/^[A-Z0-9-]{2,20}\.svg$/.test(nome)) return res.status(404).end();
//   res.set('Cache-Control', 'public, max-age=31536000, immutable');
//   res.sendFile(path.join(process.env.PASTA_DESENHOS, nome));
// });
