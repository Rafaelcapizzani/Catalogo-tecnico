// Chamado pelo publicador (api/publicador.js) quando o catálogo muda no ERP.
import { revalidateTag } from 'next/cache';
import { timingSafeEqual } from 'crypto';

export async function POST(req: Request) {
  const esperado = Buffer.from(`Bearer ${process.env.SITE_REVALIDATE_SECRET}`);
  const recebido = Buffer.from(req.headers.get('authorization') || '');
  if (esperado.length !== recebido.length || !timingSafeEqual(esperado, recebido))
    return new Response('não autorizado', { status: 401 });
  revalidateTag('catalogo');                 // listas, filtros e todas as fichas de perfil
  return Response.json({ ok: true, em: new Date().toISOString() });
}
