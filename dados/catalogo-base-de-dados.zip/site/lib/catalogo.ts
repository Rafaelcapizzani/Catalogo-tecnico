// Next.js (App Router) — leitura do catálogo a partir da API do servidor da empresa.
// As páginas ficam estáticas (rápidas e indexáveis no Google) e são refeitas quando o publicador avisa.
const API = process.env.ERP_API_URL!;          // https://api.<dominio> (Cloudflare Tunnel)
const HEADERS = {                               // Cloudflare Access — Service Token
  'CF-Access-Client-Id': process.env.CF_ACCESS_CLIENT_ID!,
  'CF-Access-Client-Secret': process.env.CF_ACCESS_CLIENT_SECRET!,
};

export type Perfil = {
  codigo: string; descricao: string; aplicacao: string; linha: string; funcao: string;
  tabelado: boolean; medidas?: { a: number; b: number; c: number; e: number };
  desenho: string | null; situacao: 'ativo' | 'sob_consulta'; peso_kg_m: number | null;
  cores_pronta_entrega: string[]; novo: boolean;
};

async function api<T>(caminho: string, tags: string[]): Promise<T> {
  const r = await fetch(`${API}${caminho}`, { headers: HEADERS, next: { tags, revalidate: 86400 } }); // reserva: 1x por dia
  if (!r.ok) throw new Error(`API do catálogo: ${r.status} em ${caminho}`);
  return r.json();
}

export const listaPerfis = () => api<Perfil[]>('/catalogo/perfis', ['catalogo']);
export const umPerfil = (codigo: string) => api<Perfil>(`/catalogo/perfis/${encodeURIComponent(codigo)}`, ['catalogo', `perfil:${codigo}`]);
// A busca por código de outro fabricante roda no servidor (as equivalências nunca chegam ao navegador):
export const busca = async (q: string) => {
  const r = await fetch(`${API}/catalogo/busca?q=${encodeURIComponent(q)}`, { headers: HEADERS, cache: 'no-store' });
  return (await r.json()) as Perfil[];
};
