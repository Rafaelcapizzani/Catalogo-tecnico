// Trecho para o next.config.js do site novo: endereços antigos do gerador de catálogo → catálogo novo (301).
// O subdomínio catalogo.ciazzani.com.br passa a apontar para o site novo (Vercel) e cai nestas regras.
module.exports.redirects = async () => [
  { source: '/:path*', has: [{ type: 'host', value: 'catalogo.ciazzani.com.br' }], destination: 'https://www.<dominio>/catalogo', permanent: true },
  { source: '/retorno.asp', destination: '/catalogo', permanent: true },
  { source: '/index.html', has: [{ type: 'host', value: 'catalogo.ciazzani.com.br' }], destination: '/catalogo', permanent: true },
];
