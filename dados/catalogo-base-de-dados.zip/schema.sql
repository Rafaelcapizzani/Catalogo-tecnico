/* =====================================================================
   Catálogo técnico — base de dados (SQL Server, schema "site")
   Alplan & Ciazzani — 25/11/2026

   Regras decididas pelo cliente (25/11):
   - O PESO vem do ERP, ao vivo: mudou no ERP, muda no site e no PDF.
     (A planilha pesos-a-validar.xlsx serve para corrigir o ERP, não o site.)
   - EQUIVALÊNCIAS (códigos de outros fabricantes) ficam gravadas e entram na
     busca, mas NUNCA são exibidas nem devolvidas pela API pública.
     Um perfil pode ter várias equivalências.
   - INATIVOS no ERP aparecem como "sob consulta".
   - CORES: o site mostra as cores a pronta entrega do perfil, mas o orçamento
     aceita qualquer cor da tabela de cores.
   - Só a view vw_catalogo_produto toca as tabelas reais do ERP: é o único
     ponto a adaptar (mesmo padrão de vw_cliente, vw_titulo etc.).
   ===================================================================== */

-- 1) Dados próprios do catálogo (o que o ERP não tem) ---------------------

CREATE TABLE site.catalogo_perfil (
    codigo          VARCHAR(20)   NOT NULL PRIMARY KEY,   -- código Alplan (ex.: SU-200)
    descricao_web   NVARCHAR(200) NULL,                   -- vazio = usa a descrição do ERP
    aplicacao       NVARCHAR(60)  NOT NULL,               -- Janelas e portas, Box e vidro temperado…
    linha           NVARCHAR(60)  NOT NULL,               -- Suprema, Gold, Linha 25…
    funcao          NVARCHAR(40)  NOT NULL,               -- Marco, Montante, Trilho…
    tabelado        BIT           NOT NULL DEFAULT 0,     -- página TABELADO (tubos, cantoneiras…)
    medida_a_mm     DECIMAL(9,2)  NULL,                   -- só tabelados
    medida_b_mm     DECIMAL(9,2)  NULL,
    medida_c_mm     DECIMAL(9,2)  NULL,
    medida_e_mm     DECIMAL(9,2)  NULL,
    desenho_arquivo VARCHAR(120)  NULL,                   -- desenhos/SU-200.svg
    desenho_hash    CHAR(64)      NULL,                   -- sha256 do SVG (cache do site e do PDF)
    cotas_json      NVARCHAR(MAX) NULL,                   -- valores, posições e direção (de _cotas.json)
    publicado       BIT           NOT NULL DEFAULT 1,     -- 0 = some do site sem apagar
    novo_ate        DATE          NULL,                   -- selo "Novo" na vitrine
    atualizado_em   DATETIME2     NOT NULL DEFAULT SYSUTCDATETIME()
);

CREATE TABLE site.catalogo_equivalencia (
    codigo          VARCHAR(20)  NOT NULL REFERENCES site.catalogo_perfil(codigo),
    codigo_equiv    VARCHAR(40)  NOT NULL,                -- como o fabricante escreve (ex.: P-147, FA-232, NX-6509)
    fabricante      NVARCHAR(40) NULL,                    -- ASA, Belmetal, Stelman… (uso interno)
    codigo_busca    AS UPPER(REPLACE(REPLACE(REPLACE(REPLACE(codigo_equiv,'-',''),' ',''),'.',''),'/','')) PERSISTED,
    CONSTRAINT pk_catalogo_equivalencia PRIMARY KEY (codigo, codigo_equiv)
);
CREATE INDEX ix_equiv_busca ON site.catalogo_equivalencia (codigo_busca);

-- 2) Área do Cliente: catálogos salvos e orçamentos ------------------------

CREATE TABLE site.catalogo_salvo (
    id          INT IDENTITY PRIMARY KEY,
    usuario_id  INT NOT NULL REFERENCES site.portal_usuario(id),
    nome        NVARCHAR(80) NOT NULL,
    criado_em   DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE site.catalogo_salvo_item (
    catalogo_id INT NOT NULL REFERENCES site.catalogo_salvo(id) ON DELETE CASCADE,
    codigo      VARCHAR(20) NOT NULL REFERENCES site.catalogo_perfil(codigo),
    ordem       INT NOT NULL DEFAULT 0,
    CONSTRAINT pk_catalogo_salvo_item PRIMARY KEY (catalogo_id, codigo)
);

CREATE TABLE site.orcamento (
    id            INT IDENTITY PRIMARY KEY,
    numero        AS ('ORC-' + RIGHT('000000' + CAST(id AS VARCHAR(6)), 6)) PERSISTED,
    usuario_id    INT NULL REFERENCES site.portal_usuario(id),  -- NULL = visitante
    nome          NVARCHAR(120) NULL,                            -- visitante
    empresa       NVARCHAR(120) NULL,
    documento     VARCHAR(18)   NULL,                            -- CNPJ/CPF do visitante
    email         VARCHAR(160)  NULL,
    telefone      VARCHAR(30)   NULL,
    cidade        NVARCHAR(80)  NULL,
    observacao    NVARCHAR(1000) NULL,
    status        VARCHAR(20) NOT NULL DEFAULT 'recebido',       -- recebido | em_atendimento | enviado | convertido | cancelado
    destino       VARCHAR(20) NULL,                              -- PENDENTE: e-mail / WhatsApp / ERP (a definir com o cliente)
    aceite_lgpd   BIT NOT NULL DEFAULT 0,
    criado_em     DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE site.orcamento_item (
    orcamento_id  INT NOT NULL REFERENCES site.orcamento(id) ON DELETE CASCADE,
    codigo        VARCHAR(20) NOT NULL REFERENCES site.catalogo_perfil(codigo),
    cor_codigo    VARCHAR(10) NOT NULL,                          -- qualquer cor da tabela de cores
    barras        INT NOT NULL CHECK (barras > 0),               -- sempre barras de 6 m
    pronta_entrega_na_hora BIT NOT NULL DEFAULT 0,              -- foto do estoque no momento do pedido
    peso_kg_m_na_hora DECIMAL(9,3) NULL,
    CONSTRAINT pk_orcamento_item PRIMARY KEY (orcamento_id, codigo, cor_codigo)
);

-- 3) Views sobre o ERP (ÚNICO ponto a adaptar às tabelas reais) ----------
/* Colunas do relatório "Itens do Estoque": CÓDIGO_AUXILIAR (= código Alplan),
   CÓDIGO_CIAZZANI, CÓDIGO_DA_COR, DESCRIÇÃO_DA_COR, SITUAÇÃO (1 ativo / 2 inativo),
   TIPO (Pronta Entrega / Por Encomenda), PESO_TEÓRICO (kg por barra de 6 m).
   NÃO expor VALOR_DE_VENDA, CUSTO nem MARGEM. */

CREATE VIEW site.vw_catalogo_produto_cor AS
SELECT  i.CODIGO_AUXILIAR                       AS codigo,
        i.CODIGO_DA_COR                         AS cor_codigo,
        i.DESCRICAO_DA_COR                      AS cor_nome,
        CASE WHEN i.TIPO = 'Pronta Entrega' THEN 1 ELSE 0 END AS pronta_entrega,
        CASE WHEN i.SITUACAO = 1 THEN 1 ELSE 0 END            AS ativo,
        CAST(i.PESO_TEORICO / 6.0 AS DECIMAL(9,3))            AS peso_kg_m
FROM    dbo.ITENS_DO_ESTOQUE i                  -- << trocar pela tabela real
WHERE   i.DISPONIBILIDADE = 'Sim';
GO

CREATE VIEW site.vw_catalogo AS
SELECT  p.codigo,
        COALESCE(NULLIF(p.descricao_web,''), MAX(e.cor_nome)) AS descricao,  -- trocar MAX(cor_nome) pela descrição do item no ERP
        p.aplicacao, p.linha, p.funcao, p.tabelado,
        p.medida_a_mm, p.medida_b_mm, p.medida_c_mm, p.medida_e_mm,
        p.desenho_arquivo, p.desenho_hash, p.cotas_json, p.novo_ate,
        CASE WHEN MAX(e.ativo) = 1 THEN 'ativo' ELSE 'sob_consulta' END       AS situacao,
        MAX(e.peso_kg_m)                                                      AS peso_kg_m,      -- ao vivo do ERP
        STRING_AGG(CASE WHEN e.pronta_entrega = 1 THEN e.cor_codigo END, ',') AS cores_pronta_entrega
FROM    site.catalogo_perfil p
LEFT JOIN site.vw_catalogo_produto_cor e ON e.codigo = p.codigo
WHERE   p.publicado = 1
GROUP BY p.codigo, p.descricao_web, p.aplicacao, p.linha, p.funcao, p.tabelado,
         p.medida_a_mm, p.medida_b_mm, p.medida_c_mm, p.medida_e_mm,
         p.desenho_arquivo, p.desenho_hash, p.cotas_json, p.novo_ate;
GO

-- Versão do catálogo: muda quando qualquer peso, situação, cor ou cadastro muda.
-- O site compara esse valor para decidir se republica (ver publicacao.md).
CREATE VIEW site.vw_catalogo_versao AS
SELECT CHECKSUM_AGG(CHECKSUM(codigo, situacao, peso_kg_m, cores_pronta_entrega, desenho_hash, aplicacao, linha, funcao, descricao)) AS versao,
       COUNT(*) AS perfis
FROM   site.vw_catalogo;
GO

-- 4) Permissões: o login da API só lê o catálogo e grava orçamentos/catálogos salvos
GRANT SELECT ON site.vw_catalogo TO api_site;
GRANT SELECT ON site.vw_catalogo_versao TO api_site;
GRANT SELECT ON site.catalogo_equivalencia TO api_site;      -- só para a busca; a API nunca devolve estas linhas
GRANT SELECT, INSERT ON site.orcamento TO api_site;
GRANT SELECT, INSERT ON site.orcamento_item TO api_site;
GRANT SELECT, INSERT, UPDATE, DELETE ON site.catalogo_salvo TO api_site;
GRANT SELECT, INSERT, UPDATE, DELETE ON site.catalogo_salvo_item TO api_site;
