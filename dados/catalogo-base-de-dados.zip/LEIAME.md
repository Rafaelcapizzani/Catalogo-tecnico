# Catálogo técnico: base de dados, API e publicação automática

Alplan & Ciazzani · 25/11/2026

Este pacote leva o catálogo técnico para o site novo e permite desligar o catalogo.ciazzani.com.br. Ele usa a mesma arquitetura da Área do Cliente: o site (Next.js na Vercel) chama a API Node.js do servidor da empresa, publicada por Cloudflare Tunnel, e a API lê o SQL Server pelo schema `site`.

## Regras decididas (25/11)

| Assunto | Regra |
|---|---|
| Peso | Vem do ERP, ao vivo (`PESO_TEÓRICO ÷ 6`). Se mudar no ERP, muda no site e no PDF. Os pesos errados se corrigem no ERP (planilha `pesos-a-validar.xlsx`). |
| Equivalências | Ficam gravadas em `site.catalogo_equivalencia` (várias por perfil) e entram na busca. Não são exibidas e a API pública nunca as devolve. |
| Inativos | Aparecem como "Sob consulta". |
| Cores | O site mostra as cores a pronta entrega, mas o orçamento aceita qualquer cor da tabela de cores (69 cores). |
| Cotas enxutas | Só na Belmetal (Atlanta) e na Euroshow. Os demais catálogos ficam como o fabricante desenhou. |

## Arquivos

| Arquivo | O que é |
|---|---|
| `schema.sql` | Tabelas do catálogo, dos catálogos salvos e dos orçamentos, mais as views sobre o ERP. Só `vw_catalogo_produto_cor` precisa ser adaptada à tabela real do ERP. |
| `carga-inicial.sql` | Carga dos 931 perfis (aplicação, linha, função, desenho e cotas) e de 708 equivalências. |
| `perfis.json` | Os mesmos dados em JSON, para conferência. |
| `desenhos/` | 617 SVGs padronizados e otimizados (21 MB), com nome igual ao código Alplan. Vão para uma pasta do servidor, que a API serve com cache longo. |
| `api/catalogo.js` | Rotas da API: `/catalogo/perfis`, `/perfis/:codigo`, `/busca`, `/versao`, `POST /orcamentos`, e `/meus/catalogos` e `/meus/orcamentos` (Área do Cliente). |
| `api/publicador.js` | Republicação automática (ver abaixo). |
| `site/lib/catalogo.ts` | Leitura do catálogo no Next.js: páginas estáticas, com a busca rodando no servidor. |
| `site/app/api/catalogo/revalidar/route.ts` | Rota que recebe o aviso de mudança e refaz as páginas. |
| `site/next.config.redirects.js` | Redirecionamentos 301 dos endereços antigos. |

## Publicação automática

1. A view `site.vw_catalogo_versao` calcula um número que muda quando qualquer peso, situação, cor a pronta entrega, desenho ou classificação muda.
2. O `publicador.js` roda dentro da API e confere esse número a cada 5 minutos.
3. Se o número mudou, o publicador chama `POST /api/catalogo/revalidar` no site, com um segredo compartilhado.
4. O site refaz as páginas do catálogo. Em no máximo 5 minutos o site reflete o ERP.
5. Reserva: mesmo sem aviso, as páginas se refazem uma vez por dia.
6. Nada fica aberto na rede da empresa: quem inicia a chamada é o servidor, para fora.

Um desenho novo ou corrigido se publica gravando o SVG na pasta de desenhos e atualizando `desenho_hash` em `site.catalogo_perfil`. O hash muda o endereço da imagem, então o cache não segura a versão antiga.

## Desligar o catalogo.ciazzani.com.br

| Etapa | O que fazer | Quando |
|---|---|---|
| 1 | Subir o catálogo novo no site e conferir com o comercial (busca, fichas, orçamento) | Antes de mexer no antigo |
| 2 | Apontar o DNS de `catalogo.ciazzani.com.br` para a Vercel e incluir o domínio no projeto. Os redirecionamentos 301 mandam qualquer endereço antigo para `/catalogo`. | No dia da virada |
| 3 | Tirar do ar o ASP: `retorno.asp`, `dados.asp`, `recebe_upload.asp`, `GerarPDF.asp` e as páginas de teste/debug | Logo após a virada |
| 4 | Revogar o usuário ODBC do MySQL usado pelo ASP e fazer backup da tabela `ItensEstoque`. As medidas A/B/C/E dos tabelados vêm dela para `site.catalogo_perfil`. | Mesma semana |
| 5 | Desligar o MySQL do catálogo e a hospedagem ASP, se nada mais usar | Após 30 dias sem acesso |
| 6 | Manter os redirecionamentos 301 por pelo menos 12 meses e conferir no Google Search Console | Contínuo |

## Pendências

| Pendência | De quem |
|---|---|
| Número do WhatsApp para o rodapé do site e do PDF | Cliente |
| PDF do catálogo (modelo A4 aprovado, QR code por página, catálogo completo para baixar): aguardando | Cliente |
| Destino do pedido de orçamento: e-mail do comercial, WhatsApp, ERP ou combinação. Hoje o pedido só fica gravado em `site.orcamento`. | Cliente (vamos discutir) |
| Validar os 123 pesos divergentes (corrigir no ERP) | Cliente |
| Revisar a classificação sugerida (`organizacao-catalogo.xlsx`), principalmente os 28 perfis "A revisar", que não têm descrição | Cliente |
| Exportar a tabela `ItensEstoque` completa do MySQL (categoria, linha, tipologia e medidas A/B/C/E) | Danilo |
| Adaptar `vw_catalogo_produto_cor` à tabela real do ERP | Danilo / Claude |
